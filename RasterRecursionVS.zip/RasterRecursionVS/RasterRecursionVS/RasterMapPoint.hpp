#ifndef RasterMapPoint_hpp
#define RasterMapPoint_hpp

#include <stdio.h>

struct RasterMapPoint {
    int x;
    int y;
};

#endif /* RasterMapPoint_hpp */
